Ingredients
11/2 cup all purpose flour
1 tsp baking powder
1/4 tsp baking soda
1 cup powder sugar
1/2 cup butter
1/2 cup milk powder
1 cup milk
1 tsp vanilla essence
For icing
1 cup whipped cream
2 tbsp icing sugar
1/4 cup glazed cherries (cut in to Small pieces
1/4 cup grated white chocolate
Some cherries
As required White chocolate
For garnishing Heart shape sprinkle