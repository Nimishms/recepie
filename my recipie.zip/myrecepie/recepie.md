In a bowl, Sieve all purpose flour, baking powder, baking soda and mix all ingredients one by one and make lump free batter with the help of electric beater.
Take cake mould and Grease with the oil, put the cake batter in mould and bake it at 180 degree for 35 to 40 minutes in preheat oven.
When it become completely cool, cut into 3 layers, spread sugar syrup on all layers.
White forest cake recipe step 3 photo
For icing, in a bowl add whipped cream and icing sugar, beat it for 10 to 15 minutes with electric beater.
Put one layer of cake on cake board, spread cream on it, put some cherries and chocolate, then put second cake layer. Again put cream, cherries, chocolate and third layer of cake.
White forest cake recipe step 5 photo
White forest cake recipe step 5 photo
White forest cake recipe step 5 photo
Cover the whole cake with the cream and keep it in refrigerator for 1 hour.
White forest cake recipe step 6 photo
Then decorate it with White chocolate, cherries and sprinkles.
White forest cake recipe step 7 photo
White forest cake recipe step 7 photo
White forest cake recipe step 7 photo
Cake is ready to serve.....
